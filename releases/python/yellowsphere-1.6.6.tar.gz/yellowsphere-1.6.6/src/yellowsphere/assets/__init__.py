"""Packaged GUI assets."""
